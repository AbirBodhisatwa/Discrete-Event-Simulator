#include "request_stream_closed.h"
#include "factory.h"

REGISTER_CLASS(RequestStream, RequestStreamClosed)

//TODO fill in
