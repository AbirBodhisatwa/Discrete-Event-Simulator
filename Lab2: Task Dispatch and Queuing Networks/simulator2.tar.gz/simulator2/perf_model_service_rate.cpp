#include "perf_model_service_rate.h"
#include "request.h"
#include "time_helper.h"
#include "factory.h"

REGISTER_CLASS(PerfModel, PerfModelServiceRate)

//TODO fill in
