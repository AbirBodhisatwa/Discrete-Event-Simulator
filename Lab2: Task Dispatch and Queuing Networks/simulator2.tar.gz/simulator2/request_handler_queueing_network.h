#ifndef REQUEST_HANDLER_QUEUEING_NETWORK_H
#define REQUEST_HANDLER_QUEUEING_NETWORK_H

#include <unordered_map>
#include <map>
#include "request_handler.h"
#include "request.h"
#include "listener.h"
#include "json/json.h"

class RequestHandlerQueueingNetwork : public RequestHandler
{
private:
    //TODO fill in

public:
    RequestHandlerQueueingNetwork(Json::Value& config);
    virtual ~RequestHandlerQueueingNetwork();

    virtual void init();

    // Handle request sent to server
    virtual void handleRequest(Request* req, ListenerEnd<Request*>* completionCallback);

    // Called when request is complete
    virtual void notifyEnd(Request* req);
};

#endif /* REQUEST_HANDLER_QUEUEING_NETWORK_H */
