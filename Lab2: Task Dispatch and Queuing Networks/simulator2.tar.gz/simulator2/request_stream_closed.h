#ifndef REQUEST_STREAM_CLOSED_H
#define REQUEST_STREAM_CLOSED_H

#include "json/json.h"
#include "request_stream.h"
#include "distribution.h"
#include "request_generator.h"

// Closed-loop request sequence
class RequestStreamClosed : public RequestStream
{
private:
    //TODO fill in

public:
    RequestStreamClosed(Json::Value& config);
    virtual ~RequestStreamClosed();

    //TODO fill in
};

#endif /* REQUEST_STREAM_CLOSED_H */
