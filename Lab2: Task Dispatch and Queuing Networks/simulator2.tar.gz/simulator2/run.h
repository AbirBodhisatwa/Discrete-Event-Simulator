#ifndef RUN_H
#define RUN_H

#include "json/json.h"

Json::Value runSimulation(Json::Value jsonRoot, bool verbose);

#endif /* RUN_H */
