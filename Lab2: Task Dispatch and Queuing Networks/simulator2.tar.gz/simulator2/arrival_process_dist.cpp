#include "arrival_process_dist.h"
#include "distribution.h"
#include "time_helper.h"
#include "factory.h"

REGISTER_CLASS(ArrivalProcess, ArrivalProcessDist)

//TODO fill in
