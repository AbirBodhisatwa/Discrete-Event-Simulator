#include <iostream>
#include "stats_latency.h"
#include "time_helper.h"
#include "factory.h"

REGISTER_CLASS(Stats, StatsLatency)

//TODO fill in

void StatsLatency::printStats(uint64_t lastIntervalBegin, uint64_t lastIntervalEnd)
{
    std::cout << "t " << lastIntervalBegin
              << " E[T] " << getMeanLatency()
              << std::endl;
}

Json::Value StatsLatency::jsonStats(uint64_t lastIntervalBegin, uint64_t lastIntervalEnd)
{
    Json::Value results;
    results["t"] = lastIntervalBegin;
    results["E[T]"] = getMeanLatency();
    return results;
}
