#include "request_stream_open.h"
#include "factory.h"

REGISTER_CLASS(RequestStream, RequestStreamOpen)

//TODO fill in
