#include "request_handler_dispatcher_random.h"
#include "random_helper.h"
#include "factory.h"

REGISTER_CLASS(RequestHandler, RequestHandlerDispatcherRandom)

//TODO fill in
