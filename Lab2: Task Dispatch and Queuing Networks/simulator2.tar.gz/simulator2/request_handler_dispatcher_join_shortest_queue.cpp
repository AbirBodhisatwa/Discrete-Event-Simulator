#include "request_handler_dispatcher_join_shortest_queue.h"
#include "factory.h"

REGISTER_CLASS(RequestHandler, RequestHandlerDispatcherJoinShortestQueue)

//TODO fill in
