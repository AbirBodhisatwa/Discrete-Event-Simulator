#include "distribution_exp.h"
#include "random_helper.h"
#include "factory.h"

REGISTER_CLASS(Distribution, DistributionExp)

//TODO fill in
// IMPORTANT: you may not use std::exponential_distribution or any other library for generating an exponential distribution
// Instead, use the uniform01 function in random_helper.h
