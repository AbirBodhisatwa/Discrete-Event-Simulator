#include "distribution_sum.h"
#include "factory.h"

REGISTER_CLASS(Distribution, DistributionSum)

//TODO fill in
