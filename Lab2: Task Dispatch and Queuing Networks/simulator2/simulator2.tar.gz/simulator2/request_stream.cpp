#include "request_stream.h"
#include "request.h"
#include "event.h"

// Add an arrival event to the event queue for the next request in reqStream
void RequestStream::addArrivalEvent()
{
    //TODO fill in
}

// Arrival callback function
void arrivalCallback(const Event& e)
{
    //TODO fill in
}
