#include <iostream>
#include "stats_throughput.h"
#include "time_helper.h"
#include "factory.h"

REGISTER_CLASS(Stats, StatsThroughput)

//TODO fill in

void StatsThroughput::printStats(uint64_t lastIntervalBegin, uint64_t lastIntervalEnd)
{
    std::cout << "t " << lastIntervalBegin
              << " X " << getThroughput(lastIntervalEnd - lastIntervalBegin)
              << std::endl;
}

Json::Value StatsThroughput::jsonStats(uint64_t lastIntervalBegin, uint64_t lastIntervalEnd)
{
    Json::Value results;
    results["t"] = lastIntervalBegin;
    results["X"] = getThroughput(lastIntervalEnd - lastIntervalBegin);
    return results;
}
