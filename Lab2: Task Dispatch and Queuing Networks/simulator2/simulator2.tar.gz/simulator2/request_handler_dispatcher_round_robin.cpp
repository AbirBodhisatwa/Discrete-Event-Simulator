#include "request_handler_dispatcher_round_robin.h"
#include "factory.h"

REGISTER_CLASS(RequestHandler, RequestHandlerDispatcherRoundRobin)

//TODO fill in
