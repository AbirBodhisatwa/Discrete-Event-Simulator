#include <cassert>
#include <set>
#include "simulator.h"

namespace simulator
{
    // Event queue in timestamp order
    std::multiset<Event> queue;
    // Global simulator time (nanoseconds)
    uint64_t simTime = 0;

    // Add an event to the event queue
    EventReference schedule(const Event& e)
    {
        assert(e.timestamp >= getSimTime()); // ensure we don't go back in time
        //TODO fill in
    }

    // Remove an event from the event queue
    void removeEvent(EventReference eventRef)
    {
        //TODO fill in
    }

    // Run simulation until no more events
    void run()
    {
        //TODO fill in
    }

    // Run simulation until stopTime (nanoseconds)
    void run(uint64_t stopTime)
    {
        //TODO fill in
    }

    // Reset simulation
    void reset()
    {
        //TODO fill in
    }
}
