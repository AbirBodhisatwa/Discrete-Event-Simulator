#include "request_generator_dist.h"
#include "distribution.h"
#include "factory.h"

REGISTER_CLASS(RequestGenerator, RequestGeneratorDist)

//TODO fill in
