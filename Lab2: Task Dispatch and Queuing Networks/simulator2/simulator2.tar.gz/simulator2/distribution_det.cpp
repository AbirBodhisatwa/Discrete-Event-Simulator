#include "distribution_det.h"
#include "factory.h"

REGISTER_CLASS(Distribution, DistributionDet)

//TODO fill in
