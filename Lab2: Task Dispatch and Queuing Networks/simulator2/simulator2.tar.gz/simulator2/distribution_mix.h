#ifndef DISTRIBUTION_MIX_H
#define DISTRIBUTION_MIX_H

#include "json/json.h"
#include "distribution.h"

class DistributionMix : public Distribution
{
private:
    //TODO fill in

public:
    DistributionMix(Json::Value& config);
    virtual ~DistributionMix();
    // Returns next random number
    virtual double nextRand();
};

#endif /* DISTRIBUTION_MIX_H */
